<?php 
/*
 *  Translated by ManiaNetwork
 *  https://github.com/NamelessMC/Nameless/
 *  NamelessMC version 2.0.0-pr10
 *
 *  License: MIT
 *
 *  Spanish/Spain Language - Language version
 */

// Which version of NamelessMC is this language file updated to?
$language_version = '2.0.0-pr10';
$language_html = 'es-ES';
