<?php 
/*
 *  Translated by ManiaNetwork
 *  https://github.com/NamelessMC/Nameless/
 *  NamelessMC version 2.0.0-pr10
 *
 *  License: MIT
 *
 *  Spanish/Spain Language - Table
 */

$language = array(
    /*
     *  Tables
     */
    'display_records_per_page' => 'Visualizar los registros de _MENU_ por página', // Don't replace "_MENU_"
    'nothing_found' => 'No se han encontrado resultados',
    'page_x_of_y' => 'Mostrando la página _PAGE_ de _PAGES_', // Don't replace "_PAGE_" or "_PAGES_"
    'no_records' => 'No hay registros disponibles',
    'filtered' => '(filtrado de _MAX_ registros totales)' // Don't replace "_MAX_"
);
