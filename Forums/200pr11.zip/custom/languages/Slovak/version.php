<?php
/*
 *  Made by RobiNN
 *  https://github.com/NamelessMC/Nameless/
 *  NamelessMC version 2.0.0-pr10
 *
 *  License: MIT
 *
 *  Slovak Language - Language version
 */

// Which version of NamelessMC is this language file updated to?
$language_version = '2.0.0-pr10';
$language_html = 'sk';