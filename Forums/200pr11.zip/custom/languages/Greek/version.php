<?php
/*
 *  Made by ArisC
 *  https://github.com/Ar1sC
 *  https://twitter.com/Ar1cC
 *  https://github.com/NamelessMC/Nameless/
 *  NamelessMC version 2.0.0-pr8
 *
 *  License: MIT
 *
 *  Greek Language - Language version
 */

// Which version of NamelessMC is this language file updated to?
$language_version = '2.0.0-pr1';
$language_html = 'el';
