<?php
/* Smarty version 3.1.39, created on 2021-08-29 04:55:49
  from '/storage/ssd2/644/17473644/public_html/Forums/custom/panel_templates/Default/update.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_612b05453e7b55_85247613',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'aaf524b6cc1cc9639ff244b60af8492127e9e331' => 
    array (
      0 => '/storage/ssd2/644/17473644/public_html/Forums/custom/panel_templates/Default/update.tpl',
      1 => 1630049317,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_612b05453e7b55_85247613 (Smarty_Internal_Template $_smarty_tpl) {
if ((isset($_smarty_tpl->tpl_vars['NEW_UPDATE']->value))) {?>
    <?php if ($_smarty_tpl->tpl_vars['NEW_UPDATE_URGENT']->value == true) {?>
        <div class="alert alert-danger">
        <?php } else { ?>
            <div class="alert alert-primary alert-dismissible" id="updateAlert">
                <button type="button" class="close" id="closeUpdate" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            <?php }?>
            <?php echo $_smarty_tpl->tpl_vars['NEW_UPDATE']->value;?>
<br />
            <a href="<?php echo $_smarty_tpl->tpl_vars['UPDATE_LINK']->value;?>
" class="btn btn-primary" style="text-decoration:none"><?php echo $_smarty_tpl->tpl_vars['UPDATE']->value;?>
</a>
            <hr /> <?php echo $_smarty_tpl->tpl_vars['CURRENT_VERSION']->value;?>

            <br /><?php echo $_smarty_tpl->tpl_vars['NEW_VERSION']->value;?>

        </div>
    <?php }
}
}
