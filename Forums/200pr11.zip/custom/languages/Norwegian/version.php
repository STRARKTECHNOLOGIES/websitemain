<?php
/*
 *  Translations by Maiu
 *  https://github.com/NamelessMC/Nameless/
 *  NamelessMC versjon 2.0.0-pr8
 *
 *  License: MIT
 *
 *  Norwegian translation (norsk bokmål) - Language Version
 */

// Which version of NamelessMC is this language file updated to?
$language_version = '2.0.0-pr8';
$language_html = 'no';
