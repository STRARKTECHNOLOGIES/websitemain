<?php
$language = array(
    //forums
    'info_forums_lock' => 'Locked',
    'info_forums_unlock' => 'Unlocked',
);