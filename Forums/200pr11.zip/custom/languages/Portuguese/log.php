<?php
$language = array(
    //forums
    'info_forums_lock' => 'Bloqueado',
    'info_forums_unlock' => 'Desbloqueado',
);