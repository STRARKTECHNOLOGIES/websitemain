<?php 
/*
 *  Made by Samerton
 *  https://github.com/NamelessMC/Nameless/
 *  NamelessMC version 2.0.0-pr8
 *
 *  License: MIT
 *
 *  EnglishUK Language - Language version
 */

// Which version of NamelessMC is this language file updated to?
$language_version = '2.0.0-pr10';
$language_html = 'en';