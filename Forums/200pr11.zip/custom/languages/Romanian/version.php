<?php
/*
 *  Made by Samerton
 *  https://github.com/NamelessMC/Nameless/
 *  NamelessMC version 2.0.0-pr8
 *
 *  License: MIT
 *
 *  Romanian Language - Language version
 *  Translation By @BaxAndrei ( https://baxandrei.ro )
 *  Last Update: 16/06/2018
 */

// Which version of NamelessMC is this language file updated to?
$language_version = '2.0.0-pr8';
$language_html = 'ro';
