<?php
/* Smarty version 3.1.39, created on 2021-08-29 04:55:49
  from '/storage/ssd2/644/17473644/public_html/Forums/custom/panel_templates/Default/footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_612b05454a9701_85134353',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '547727b205131e42e3ade4a629dc93d6c43aa248' => 
    array (
      0 => '/storage/ssd2/644/17473644/public_html/Forums/custom/panel_templates/Default/footer.tpl',
      1 => 1630049312,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_612b05454a9701_85134353 (Smarty_Internal_Template $_smarty_tpl) {
?><footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span><?php echo $_smarty_tpl->tpl_vars['PAGE_LOAD_TIME']->value;?>
</span>&nbsp;&nbsp;&nbsp;&nbsp;
            <span>&copy; NamelessMC <?php echo date('Y');?>
</span><br /><br />
                        <a href="https://github.com/NamelessMC/Nameless" target="_blank"><i class="fab fa-github fa-fw"></i> <?php echo $_smarty_tpl->tpl_vars['SOURCE']->value;?>
</a>&nbsp;&nbsp;&nbsp;&nbsp;
            <a href="https://namelessmc.com" target="_blank"><i class="fas fa-life-ring fa-fw"></i> <?php echo $_smarty_tpl->tpl_vars['SUPPORT']->value;?>
</a>
        </div>
    </div>
</footer><?php }
}
