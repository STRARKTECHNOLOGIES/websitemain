<?php
/*
 *  Gemaakt door Samerton
 *  en vertaald door Sander Lambrechts en Derkades
 *
 *  https://github.com/NamelessMC/Nameless/
 *  NamelessMC version 2.0.0-pr8
 *
 *  License: MIT
 *
 *  Nederlandse taal - Taal versie
 */

// Welke versie van NamelessMC is dit taal bestand geüpdatet voor?
$language_version = '2.0.0-pr8';
$language_html = 'nl';
