<?php
/*
 *  Made by Samerton
 *  https://github.com/NamelessMC/Nameless/
 *  NamelessMC version 2.0.0-pr9
 *
 *  License: MIT
 *
 *  Chinese Simplified Language - Language version
 *  Translation(Chinese Simplified) by ahdg,lian20,LingDong,NEWLY_1129514,Dreta
 *  Translation progress(v2-pr9) : 100%
 */

// Which version of NamelessMC is this language file updated to?
$language_version = '2.0.0-pr9';
$language_html = 'zh_cn';
