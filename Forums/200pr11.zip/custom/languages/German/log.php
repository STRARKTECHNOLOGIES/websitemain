<?php
/*
 *  Made by Samerton
 *  Translation by BukkitTNT, M_Viper
 *  https://github.com/NamelessMC/Nameless/
 *  NamelessMC version 2.0.0-pr9
 *
 *  License: MIT
 *
 *  German Language - Forum
 */
$language = array(
    //forums
    'info_forums_lock' => 'Gesperrt',
    'info_forums_unlock' => 'Entsperrt',
);
