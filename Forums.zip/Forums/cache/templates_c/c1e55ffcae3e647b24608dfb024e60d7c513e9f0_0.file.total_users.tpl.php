<?php
/* Smarty version 3.1.39, created on 2021-08-29 04:55:49
  from '/storage/ssd2/644/17473644/public_html/Forums/custom/panel_templates/Default/collections/dashboard_stats/total_users.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_612b05453f8125_33390994',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c1e55ffcae3e647b24608dfb024e60d7c513e9f0' => 
    array (
      0 => '/storage/ssd2/644/17473644/public_html/Forums/custom/panel_templates/Default/collections/dashboard_stats/total_users.tpl',
      1 => 1630051703,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_612b05453f8125_33390994 (Smarty_Internal_Template $_smarty_tpl) {
?>
<div class="col-xl-3 col-md-6 mb-4">
    <div class="card stats-card border-left-primary shadow h-100 py-2">
        <div class="card-body">
            <div class="row no-gutters align-items-center">
                <div class="col mr-2">
                    <div class="text-xs font-weight-bold text-primary text-uppercase mb-1"><?php echo $_smarty_tpl->tpl_vars['TITLE']->value;?>
</div>
                    <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $_smarty_tpl->tpl_vars['VALUE']->value;?>
</div>
                </div>
                <div class="col-auto">
                    <?php echo $_smarty_tpl->tpl_vars['ICON']->value;?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php }
}
