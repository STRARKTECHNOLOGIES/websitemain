<?php
$language = array (
    //forums
    'info_forums_lock' => 'Uzamčeno',
    'info_forums_unlock' => 'Odemčeno'
);