<?php
/*
 *  Made by Samerton
 *  https://github.com/NamelessMC/Nameless/
 *  NamelessMC version 2.0.0-pr8
 *
 *  License: MIT
 *
 *  Chinese Language - Version
 *  翻譯有誤請使用GitHun回報issues
 *  https://github.com/haer0248/NamelessMC-v2-Traditional-Chinese/issues
 */

// Which version of NamelessMC is this language file updated to?
$language_version = '2.0.0-pr3';
$language_html = 'zh-TW';
