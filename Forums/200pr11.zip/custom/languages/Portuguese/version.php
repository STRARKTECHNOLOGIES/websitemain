<?php
/*
 *  Made by Samerton
 *  https://github.com/NamelessMC/Nameless/
 *  NamelessMC version 2.0.0-pr8
 *
 *  License: MIT
 *
 *  Portuguese Language - Language version
 *  Translation By Douglas Teles & Mansffer
 *  Last Update: 01/03/2021
 */
// Which version of NamelessMC is this language file updated to?
$language_version = '2.0.0-pr9';
$language_html = 'pt-br';
