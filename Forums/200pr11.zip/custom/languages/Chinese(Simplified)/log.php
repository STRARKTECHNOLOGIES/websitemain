<?php
/*
 *  Made by Samerton
 *  https://github.com/NamelessMC/Nameless/
 *  NamelessMC version 2.0.0-pr9
 *
 *  License: MIT
 *
 *  Chinese (Simplified) Language - Log
 */
$language = array(
    // forums
    'info_forums_lock' => '上锁',
    'info_forums_unlock' => '解锁',
);
