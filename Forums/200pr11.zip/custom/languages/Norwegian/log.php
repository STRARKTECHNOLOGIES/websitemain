<?php
$language = array(
    //forums
    'info_forums_lock' => 'Låst',
    'info_forums_unlock' => 'Opplåst',
);
