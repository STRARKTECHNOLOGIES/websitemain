---
name: "\U0001F41B Bug report"
about: Inform us of any bugs/issues you may have found

---

**Describe the issue**
Please describe the issue in as much detail as possible

**To Reproduce**
Steps to reproduce the behaviour:
1. Go to '...'
2. Click on '....'
3. Scroll down to '....'
4. See error

**Expected behaviour**
What were you expecting to happen?

**Screenshots**
If applicable, add screenshots to help explain your problem.

**NamelessMC version (from AdminCP -> Overview)**

**Additional information**
Add more information about the problem if necessary.
