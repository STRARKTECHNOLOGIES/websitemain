<?php
/*
 *  Made by Samerton
 *  https://github.com/NamelessMC/Nameless/
 *  NamelessMC version 2.0.0-pr10
 *
 *  Translator
 *  - snake( @ViaSnake, https://github.com/ViaSnake )
 *
 *  License: MIT
 *
 *  Japanese Language - Log
 */

$language = array(
    //forums
    'info_forums_lock' => 'ロック',
    'info_forums_unlock' => 'ロック解除',
);