<?php 
/*
 *  Made by Samerton & Translated by Codiaz
 *  https://github.com/NamelessMC/Nameless/
 *  NamelessMC version 2.0.0-pr8
 *
 *  License: MIT
 *
 *  Danish Language - General terms
 */

// Which version of NamelessMC is this language file updated to?
$language_version = '2.0.0-pr8';
$language_html = 'da';